﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.UserSupport.RemoteChat
{
    [MessagePackObject]
    public class DoChatAction : IMessage
    {
      
    }
}
