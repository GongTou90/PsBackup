﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.QuickCommands
{
    [MessagePackObject]
    public class DoEnableUAC : IMessage
    {

    }
}
