﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Monitoring.RemoteDesktop
{
    [MessagePackObject]
    public class GetMonitors : IMessage
    {
    }
}
