﻿namespace Pulsar.Server.Enums
{
    public enum WordType
    {
        DWORD,
        QWORD
    }
}
