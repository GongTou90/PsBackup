namespace Pulsar.Server.Utilities
{
    public static class ServerVersion
    {
        public const string Current = "2.4.6";

        public static string Display => $"v{Current}";
    }
}
