﻿namespace Pulsar.Common.Enums
{
    public enum StartupType
    {
        LocalMachineRun,
        LocalMachineRunOnce,
        CurrentUserRun,
        CurrentUserRunOnce,
        StartMenu,
        LocalMachineRunX86,
        LocalMachineRunOnceX86
    }
}
