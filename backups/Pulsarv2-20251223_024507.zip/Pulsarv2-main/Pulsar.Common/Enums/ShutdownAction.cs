﻿namespace Pulsar.Common.Enums
{
    public enum ShutdownAction
    {
        Shutdown,
        Restart,
        Standby,
        Lockscreen
    }
}
