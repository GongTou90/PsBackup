using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Pulsar Common Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Pulsar")]
[assembly: AssemblyCopyright("Copyright © PulsarTeam 2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("cfda6d2e-8ab3-4349-b89a-33e1f0dab32b")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("2.4.6")]
[assembly: AssemblyFileVersion("2.4.6")]
