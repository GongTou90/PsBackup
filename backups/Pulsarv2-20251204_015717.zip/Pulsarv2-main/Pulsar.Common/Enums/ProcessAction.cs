﻿namespace Pulsar.Common.Enums
{
    public enum ProcessAction
    {
        Start,
        End,
        SetTopMost,
        None,
        Suspend
    }
}
