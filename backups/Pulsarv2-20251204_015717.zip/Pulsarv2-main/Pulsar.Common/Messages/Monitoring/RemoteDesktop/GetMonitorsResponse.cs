﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages
{
    [MessagePackObject]
    public class GetMonitorsResponse : IMessage
    {
        [Key(1)]
        public int Number { get; set; }
    }
}
