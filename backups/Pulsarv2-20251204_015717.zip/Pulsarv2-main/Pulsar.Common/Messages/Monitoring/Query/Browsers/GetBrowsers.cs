﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.Monitoring.Query
{
    [MessagePackObject]
    public class GetBrowsers : IMessage
    {

    }
}
