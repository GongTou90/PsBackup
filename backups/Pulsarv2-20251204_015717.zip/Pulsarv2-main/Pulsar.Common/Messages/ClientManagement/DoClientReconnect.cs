﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages
{
    [MessagePackObject]
    public class DoClientReconnect : IMessage
    {
    }
}
