﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.ClientManagement
{
    [MessagePackObject]
    public class DoClientUninstall : IMessage
    {
    }
}
