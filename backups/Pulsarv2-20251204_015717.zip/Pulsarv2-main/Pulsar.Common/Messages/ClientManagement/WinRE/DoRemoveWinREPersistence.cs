﻿using MessagePack;
using Pulsar.Common.Messages.Other;

namespace Pulsar.Common.Messages.ClientManagement.WinRE
{
    [MessagePackObject]
    public class DoRemoveWinREPersistence : IMessage
    {
    }
}
